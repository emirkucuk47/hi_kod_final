import 'package:flutter/material.dart';
import 'weather_property.dart';
import 'weather_page.dart';

/// Flutter code sample for [TextField].
/*class CityEntering extends StatefulWidget {
  const CityEntering({Key? key}) : super(key: key);

  @override
  State<CityEntering> createState() => CityEnteringState();
}

class CityEnteringState extends State<CityEntering> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            SizedBox(
              height: 220,
            ),
            TextField(
              obscureText: false,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Enter A City',
              ),
            ),
            SizedBox(
              height: 5,
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Weather_Page()),
                );
              },
              child: Text('GO'),
            ),
          ],
        ),
      ),
    );
  }
}*/

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        //appBar: AppBar(title: Text('HOWEATHER')),
        body: Center(
          child: Weather_Page(),
        ),
      ),
    );
  }
}

void main() => runApp(const MyApp());

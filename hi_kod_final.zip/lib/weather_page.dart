import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:hi_kod_final/weather_property.dart';
import 'package:hi_kod_final/weather_service.dart';
import 'package:location/location.dart';
import 'package:geolocator_platform_interface/src/enums/location_accuracy.dart';

class Weather_Page extends StatefulWidget {
  const Weather_Page({Key? key}) : super(key: key);

  @override
  State<Weather_Page> createState() => Weather_Page_State();
}

class Weather_Page_State extends State<Weather_Page> {
  final _weather_service = WeatherService('a20161304a85c706ec405e5f40f69c37');
  Weather? _weather;

  FetchWeather() async {
    String city_name = await _weather_service.GetCurrentCity();

    try {
      final weather = await _weather_service.getWeather(city_name);

      setState(() {
        _weather = weather;
      });
    } catch (e) {
      print(e);
    }

    @override
    void initState() {
      super.initState();

      FetchWeather();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('HOWEATHER')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(_weather?.city_name ?? "LOADING..."),
            Text('${_weather?.temperature.round()} °C'),
            FloatingActionButton(
              onPressed: () {
                //WeatherService();
                //
                Geolocator.requestPermission();
                Geolocator.getCurrentPosition();
                forceAndroidLocationManager:
                true;

                //
              },
              child: Icon(Icons.add),
            )
          ],
        ),
      ),
    );
  }
}

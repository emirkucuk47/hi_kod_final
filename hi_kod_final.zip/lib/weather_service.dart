import 'dart:convert';

import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:hi_kod_final/weather_property.dart';
import 'package:http/http.dart' as http;

class WeatherService {
  static const base_url = 'https://api.openweathermap.org/data/3.0/weather';
  final String api_key;

  WeatherService(this.api_key);

  Future<Weather> getWeather(String city_name) async {
    final response = await http
        .get(Uri.parse('$base_url?q=$city_name&appid=$api_key&units=metric'));

    if (response.statusCode == 200) {
      return Weather.fromJson(jsonDecode(response.body));
    } else {
      throw Exception('Failed To Fetch The Weather Data');
    }
  }

  Future<String> GetCurrentCity() async {
    LocationPermission permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    Position position = await Geolocator.getCurrentPosition(
      forceAndroidLocationManager: true,
      desiredAccuracy: LocationAccuracy.best,
    );

    List<Placemark> placemarks =
        await placemarkFromCoordinates(position.latitude, position.longitude);

    String? city = placemarks[0].locality;

    return city ?? "";
  }
}

package com.example.hi_kod_final

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
